#!/bin/bash

echo "example.1 42"
echo "example.2 24"
echo "example.3 12.1212"
